CHANGES (2026-10-28, requested updates)
  1. Sender and Receiver project target framework changed to .NET Framework 4.8.
  2. Receiver DB Search > Download file suggests the filename from the received data before the first comma or space.
  3. Working directory keeps the existing <data>.txt naming. Working directory monitor saves <data>_yyyyMMddHHmmss.txt (24-hour time).
  4. Receiver Settings > 6. Other > Receiver display name controls the first name in the main status line, e.g.
     "M2M Receiver_1 Is Receiving Data From HB-1 Now... (1 sender(s))".
  Build not run here because a .NET compiler is not installed in this environment.

CHANGES (2026-10-27, tell several Receivers apart)
  Receiver > Settings > 6. Other > "Window name (optional)". Empty (default) = title is only "M2M Receiver".
  Example: type Line1  ->  title "M2M Receiver - Line1". Set a different name in each copy (folder). The status line
  inside the window also shows its IP:Port ("Waiting for data on 127.0.0.1:1901 ...").

CHANGES (2026-10-27, window title + more than one Receiver on one PC)
  1. Window title is now just "M2M Receiver" / "M2M Sender" (no version text / date). The cfg line
     Software_VersionInformation is still in the file, it is just not shown.
  2. Two or three Receivers on ONE PC:
       - Make a folder per Receiver, for example  C:\M2M\Receiver_A , C:\M2M\Receiver_B , C:\M2M\Receiver_C
       - Copy M2M_Receiver_1.exe into each folder (each folder gets its own .cfg and DB).
       - Start each one, Settings... (password) and give EACH a different Port (1900, 1901, 1902) and a different
         Working directory / Monitor folder. The Sender for each machine connects to its own port.
     The "already open" message now appears only if the SAME folder is started twice (same port would clash).
     If two Receivers use the same Port the second one shows red "Cannot listen: ..." - change its Port.

CHANGES (2026-10-27, file name)
  Receiver: the saved file is named after the data in front of the FIRST comma or space of the received message.
    ALPCUCH0000101,0,0,0,0,0,0,GVD123456789012345,...   ->   ALPCUCH0000101.txt   (extension = "File format" setting)
  If a file with that name already exists, the OLD file is replaced by the NEW data (only the newest file stays in the
  Working directory and in the Monitor folder). Nothing is lost: every message is still in DB\yyyy-MM-dd.udb, so the old
  data can be found in DB Search and downloaded (Download file tab, download symbol).
  Characters Windows does not allow in a file name are replaced by "_". If the message has nothing usable in front of the
  first comma / space, the old name M2M_yyyyMMdd_HHmmss_fff is used. The Monitor-folder copy gets the same name.
  Nothing else was changed.

CHANGES (2026-10-27, status colour)
  Status line colour: connected = DARK GREEN, not connected = RED.
    Sender  : connected to the Receiver IP:port = dark green; connecting / disconnected / reconnecting = red.
    Receiver: a Sender is connected = dark green; waiting for a sender / not listening = red.

CHANGES (2026-10-27, third request)
  1. Sender: new button "Load File..." (next to Auto-send / Send). Choose a .txt, .xml or .csv file; its content is sent
     as ONE message (same as a file from the send folder: Framing / Checksum / ACK settings are used). The Receiver saves it
     as a file in its Working directory. The file itself is not moved or changed.
  2. Receiver > DB Search: new tab "Download file" where you choose the format: Text (.txt) / XML (.xml) / CSV (.csv).
     In the list every received record has a download symbol (down arrow) in the first column. Click it -> Save dialog ->
     that record is saved in the chosen format:
        Text = exactly the received content
        XML  = <M2M_Data><Message time="..."><![CDATA[ content ]]></Message></M2M_Data>
        CSV  = header "Time,Content" + one row (content in quotes)
     The old "Export CSV..." button (all found records) is still there.
  3. "Developed by SH" (bold black, bottom right) is kept.

CHANGES (2026-10-27, last request)
  1. The "Change password..." button is no longer in the main window (Receiver and Sender).
     It is now inside Settings: Settings... > enter the password > "Change password..." button at the bottom of the window.
  2. Bottom bar, right side: "Developed by SH" in bold black text (Receiver and Sender).
  Nothing else was changed.

ERROR "type or namespace 'M2M' / IniConfig / FramingMode could not be found"
  The shared code files (Framing.cs, IniConfig.cs, PasswordGate.cs, UiHelpers.cs) are now directly INSIDE each project
  folder, next to MainForm.cs. No link, no Shared folder. If you copy files into your own Visual Studio project, copy
  ALL .cs files of the project folder (all 7 in the Receiver, all 7 in the Sender - none may be missing).

NETSDK1004 "Assets file project.assets.json not found" (Sender)
  Visual Studio did not run the package restore for that project. Do ONE of these:
   a) Open  M2M.sln  (new, in this folder) - both projects restore together - then Build > Rebuild Solution.
   b) Or in a command window in this folder:   dotnet restore M2M.sln
   c) Or run Build_Offline.bat (it restores and builds both).

FIX 2026-10-27 (build error NU1100 / NETSDK1004)
  The projects now target net10.0-windows (your SDK is 10.0.301). The SDK 10 contains the net10 packs, so nothing
  must be downloaded. With net8.0-windows the SDK 10 wanted the 8.0.28 packs from the internet = the NU1100 error.
  If a project was already tried before: delete its obj and bin folders once (Build_Offline.bat does this itself),
  then build again. SDK 8 PC: Build_Offline.bat switches the target to net8.0-windows by itself.
  The line PC needs the ".NET 10 Desktop Runtime" (x64).

=====================================================================================
VERSION 2  (2026-10-27)  - what is new in this zip
=====================================================================================

CHECKED FIRST (your M2M_Receiver_1.zip)
  - M2M_Receiver_1.exe is the SAME file as the one checked before (identical hash), so nothing new to port.
  - Your DB\*.udb files (1184 records, Jan-Sep 2026) confirm the old format: "yyyy-MM-dd HH:mm:ss.fff|content",
    CRLF line ends, no special characters.  The new Receiver writes exactly this format (the DB Search reads the old files).
  - Difference found and FIXED: the old Receiver also wrote EMPTY messages into the DB (e.g. 31 of 32 records on
    2026-01-21, 8 on 2026-09-07). The first rebuild skipped them. Now they are logged to the DB like before
    (setting "Log empty messages to DB", default = true). No file is created for an empty message.
  - Your cfg uses CR-only line ends: handled, and the file is saved back the same way.

NEW FEATURES (all OFF / same as old by default - nothing changes until you turn them on)
  1. DB Search      Button "DB Search..." (Receiver). Pick a date or "All dates", type a text (for example a
                    GVD... barcode or a serial number), Search. Click a row to see the full message. "Export CSV..." saves
                    the result for Excel. Works on all your old .udb files.
  2. Statistics     New line under the status: messages today, time of the last message, duplicates skipped.
  3. No-data alarm  Settings > 7 > "No-data alarm (minutes)". If nothing arrives for that long: red bar + log line + beep.
                    Clears by itself when data comes again. 0 = off.
  4. Allowed IPs    Settings > 7 > "Allowed sender IPs" (comma separated). Other PCs are refused. Empty = everyone (old).
  5. Duplicate filter  Settings > 7 > "Duplicate filter (seconds)". The same text again within N seconds is not saved twice;
                    the sender still gets its ACK, so it does not retry. 0 = off (old: everything is saved).

  6. NO DATA LOSS   (always on)  Order for every message: 1) written to DB\yyyy-MM-dd.udb and flushed to disk,
                    2) saved as file in Working directory + Monitor folder. If a folder is not reachable (network drive down,
                    disk full) the file is kept in the "Pending" folder next to the exe and delivered automatically every 10 s,
                    also after a restart. The status line shows "WAITING IN PENDING: n". The DB always has the message.
                    For a guarantee up to the SENDER: turn on Auto-ACK (Receiver) + Wait for ACK with retries (Sender) and use
                    Framing = Line / StxEtx / LengthPrefix with a Checksum. Then a message is acknowledged only after it is safe.

  7. Icon           Receiver has its own icon (M2M_Receiver\\AppIcon.ico): orange rounded square, white download arrow
                    (same orange style as PDCA Sender). To use another one, replace that .ico file and build again.

OFFLINE BUILD (no internet)
  Double-click  Build_Offline.bat
    - needs only the .NET SDK installed on the PC (no NuGet download: the projects use no packages)
    - it reads your SDK version and builds for it automatically (SDK 8 -> net8.0-windows, SDK 10 -> net10.0-windows),
      so the old "NETSDK1004" problem cannot come back
    - result: ONE single exe per app, icon inside:  Output\M2M_Receiver_1.exe  and  Output\M2M_Sender.exe
      (framework-dependent single file, 64-bit Windows, nothing is downloaded)
  The line PC needs the ".NET Desktop Runtime" of the same major version (offline installer is enough).
  A fully self-contained exe (no runtime needed) must be published once on a PC WITH internet:
    dotnet publish M2M_Receiver\M2M_Receiver_1.csproj -c Release -r win-x64 --self-contained -p:PublishSingleFile=true

NOT TESTED: no .NET compiler was available where this was written. If Build_Offline.bat shows an error, send me the
error text and I will fix it.

M2M Receiver + M2M Sender  (rebuilt from the old M2M_Receiver_1.exe / M2M_Sender.exe)
=====================================================================================

FOLDERS
  (each project folder has its own Shared\ subfolder: cfg reader, framing/checksum, password, settings window, log box)
  M2M_Receiver\   M2M_Receiver_1.csproj   -> builds M2M_Receiver_1.exe
  M2M_Sender\     M2M_Sender.csproj       -> builds M2M_Sender.exe

BUILD (Visual Studio)
  File > Open > Project/Solution > choose M2M_Receiver\M2M_Receiver_1.csproj  > F5
  then the same for M2M_Sender\M2M_Sender.csproj
  
  If your Visual Studio / SDK uses another .NET version, change <TargetFramework> in the .csproj
  (net8.0-windows -> net10.0-windows) the same way as you did for the TCP Terminal.

  Exe for the line PC (no .NET install needed there):
    dotnet publish -c Release -r win-x64 --self-contained -p:PublishSingleFile=true

CONFIG FILES (next to the exe)
  M2M_Receiver_1.cfg and M2M_Sender.cfg. Your OLD .cfg files work as they are: copy them next to the new exe.
  Keys that are missing are added with defaults the first time you press "Save & Apply" in Settings.
  Everything can be changed in the app: Settings...  (asks for the close password).

DEFAULT BEHAVIOUR = OLD BEHAVIOUR
  Framing = None, no ACK, no auto-reply, password xyz678 -> works like the old apps.
  Turn the new features on in Settings, on BOTH sides (Sender and Receiver must use the same Framing / Checksum / ACK text).

NEW FEATURES
  1. Multiple clients   Receiver accepts many senders at the same time. Table at the top shows each sender.
                        Settings > Max clients limits it (0 = no limit).
  2. Message format     Framing: None / Line / StxEtx / LengthPrefix / Fixed.  Checksum: XOR / SUM8 / CRC16
                        (ASCII hex inside StxEtx and LengthPrefix frames). Bad checksum = message rejected + NAK.
  3. ACK                Receiver: Auto-ACK (ACK after the file is saved, NAK on error / bad checksum).
                        Sender: Wait for ACK + timeout + retries. A file in the send folder is only moved to "Sent"
                        after it was acknowledged.
  4. Auto-send          Sender: send a fixed text every N ms (tick "Auto-send" in the main window; text in Settings).
     Auto-reply         Receiver: reply with a text when a message contains a word. It switches itself off if
                        more than 200 automatic replies happen in one second (two devices answering each other).
  5. Settings save      All settings are stored in the .cfg files. Settings window = PropertyGrid. The password can
                        be changed in the app and is then stored as a hash, not as plain text.

WHAT I COULD NOT SEE IN THE OLD EXEs (no source code) - these are ASSUMPTIONS, please check:
  - Receiver saves each message as  <WorkingDirectory>\M2M_yyyyMMdd_HHmmss_fff.txt  (+ a copy in the monitor folder)
    and writes  DB\yyyy-MM-dd.udb  as  "timestamp|content".  The real old file naming may be different.
  - A message that is exactly the "M2M_CommunicationTestString" is answered but not saved.
  - Sender reads files from  M2M_Sender_SendFolder  (new key, default C:\SH\M2M_SendFolder), oldest first,
    sends the whole file as ONE message and moves it to "Sent". The old Sender may get its data another way.
  - Status line text and the "Fuzion Machine Sent To AOI:" log text are copied from the old exes.
  - Old exes were .NET Framework 4.0. These are .NET 8: the line PCs need the .NET 8 Desktop Runtime,
    or use the self-contained publish above.

QUICK TEST (one PC)
  1. Start M2M_Receiver_1.exe (127.0.0.1:1900).  2. Start M2M_Sender.exe.
  3. Put a .txt file in C:\SH\M2M_SendFolder  -> it appears in C:\SH\M2M_ReceivedFolder and in DB\<date>.udb.
  Two PCs: Receiver IP = the Receiver PC's LAN IP (or 0.0.0.0), Sender "Receiver IP address" = that same IP.
  Windows Firewall must allow the port.
