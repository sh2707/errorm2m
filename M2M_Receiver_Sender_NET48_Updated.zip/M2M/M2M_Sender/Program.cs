namespace M2M_Sender;

static class Program
{
    [STAThread]
    static void Main()
    {
        // only one copy of the app may run (same as the old M2M_Sender)
        using var mutex = new Mutex(true, "M2M_Sender_SingleInstance", out bool isFirst);
        if (!isFirst)
        {
            MessageBox.Show("You can't open this APP because it has already been open !!!", "Tip",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new MainForm());
    }
}
