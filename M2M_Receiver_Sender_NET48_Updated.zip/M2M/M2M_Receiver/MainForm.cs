using System.Net;
using System.Net.Sockets;
using System.Text;
using M2M.Shared;

namespace M2M_Receiver;

public class MainForm : Form
{
    private const string AppName = "M2M Receiver_1";
    private static readonly string CfgPath = Path.Combine(Application.StartupPath, "M2M_Receiver_1.cfg");
    private static readonly string DbDir = Path.Combine(Application.StartupPath, "DB");

    private readonly IniConfig cfg;
    private ReceiverSettings settings;

    // ---- UI ----
    private readonly Label lblStatus = new()
    {
        Dock = DockStyle.Top,
        Height = 46,
        TextAlign = ContentAlignment.MiddleCenter,
        Font = new Font("Microsoft Sans Serif", 13, FontStyle.Bold),
        ForeColor = Color.Red,
        Text = "Starting ..."
    };
    private readonly ListView lvClients = new()
    {
        Dock = DockStyle.Top,
        Height = 150,
        View = View.Details,
        FullRowSelect = true,
        GridLines = true
    };
    private readonly LogBox txtLog = new() { Dock = DockStyle.Fill };
    private readonly FlowLayoutPanel bottom = new() { Dock = DockStyle.Fill, Padding = new Padding(6) };
    private readonly Panel bottomBar = new() { Dock = DockStyle.Bottom, Height = 44 };
    private readonly Label lblDev = new()
    {
        Text = "Developed by SH",
        Dock = DockStyle.Right,
        Width = 140,
        TextAlign = ContentAlignment.MiddleRight,
        Padding = new Padding(0, 0, 10, 0),
        Font = new Font("Microsoft Sans Serif", 9.5f, FontStyle.Bold),
        ForeColor = Color.Black
    };
    private readonly Button btnSettings = new() { Text = "Settings...", Width = 100 };
    private readonly Button btnClearLog = new() { Text = "Clear log", Width = 90 };
    private readonly Button btnDb = new() { Text = "DB Search...", Width = 100 };
    private readonly Label lblStats = new()
    {
        Dock = DockStyle.Top,
        Height = 24,
        TextAlign = ContentAlignment.MiddleCenter,
        Font = new Font("Microsoft Sans Serif", 9.5f, FontStyle.Bold),
        ForeColor = Color.DimGray,
        Text = ""
    };

    // ---- state ----
    private sealed class ClientState
    {
        public int Id;
        public TcpClient Tcp = null!;
        public NetworkStream Stream = null!;
        public string Remote = "";
        public DateTime Since;
        public int Messages;
        public MessageAssembler Assembler { get; } = new();
        public ListViewItem Row = null!;
        public SemaphoreSlim WriteLock { get; } = new(1, 1);
    }

    private readonly List<ClientState> clients = new();
    private int nextClientId;
    private TcpListener? listener;
    private CancellationTokenSource? cts;
    private readonly System.Windows.Forms.Timer gapTimer = new();
    private string? listenError;

    // statistics / alarm / duplicate filter
    private DateTime statsDay = DateTime.Today;
    private int todayCount;
    private DateTime lastReceived = DateTime.MinValue;
    private DateTime alarmBase = DateTime.Now;
    private bool alarmActive;
    private int duplicatesSkipped;
    private long lastSecondTick;
    private readonly Dictionary<string, DateTime> recent = new();

    // auto-reply safety: stop if two devices keep answering each other
    private long autoWindowStart;
    private int autoWindowCount;

    public MainForm()
    {
        bool firstRun = !File.Exists(CfgPath);
        cfg = new IniConfig(CfgPath);
        settings = ReceiverSettings.LoadFrom(cfg);
        if (firstRun) settings.SaveTo(cfg);

        ApplyTitle();
        try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { /* icon is optional */ }
        ClientSize = new Size(760, 520);
        MinimumSize = new Size(640, 400);
        StartPosition = FormStartPosition.CenterScreen;

        lvClients.Columns.Add("#", 40);
        lvClients.Columns.Add("Sender (IP:port)", 190);
        lvClients.Columns.Add("Connected since", 120);
        lvClients.Columns.Add("Messages", 80);

        bottom.Controls.Add(btnSettings);
        bottom.Controls.Add(btnClearLog);
        bottom.Controls.Add(btnDb);

        // dock order: the control added last is laid out first
        Controls.Add(txtLog);
        Controls.Add(lvClients);
        Controls.Add(lblStats);
        Controls.Add(lblStatus);
        bottomBar.Controls.Add(bottom);   // dock order: the control added last is laid out first
        bottomBar.Controls.Add(lblDev);
        Controls.Add(bottomBar);

        todayCount = DbReader.CountRecords(DbReader.FileFor(DbDir, DateTime.Today));

        btnSettings.Click += (_, _) => OpenSettings();
        btnClearLog.Click += (_, _) => txtLog.Clear();
        btnDb.Click += (_, _) => { using var dlg = new DbViewerForm(DbDir); dlg.ShowDialog(this); };
        gapTimer.Tick += (_, _) => { PollGaps(); SecondTick(); };
        Shown += (_, _) => ApplySettings();
    }

    // ================= settings =================

    private void OpenSettings()
    {
        if (!PasswordGate.Ask(this, cfg, "Settings")) return;

        var copy = settings.Clone();
        using var dlg = new SettingsForm(copy, AppName + " - Settings", cfg);
        if (dlg.ShowDialog(this) != DialogResult.OK) return;

        copy.Normalize();
        try
        {
            copy.SaveTo(cfg);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Cannot save the .cfg file: " + ex.Message, "Tip", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        settings = copy;
        Log("Settings saved - restarting the listener");
        ApplySettings();
    }

    private void ApplyTitle()
    {
        Text = settings.WindowName.Length > 0 ? "M2M Receiver - " + settings.WindowName : "M2M Receiver";
    }

    private void ApplySettings()
    {
        ApplyTitle();
        StopListening();
        txtLog.MaxLines = settings.MaxLogLines;
        gapTimer.Interval = Math.Max(10, settings.TimerInterval);
        gapTimer.Start();
        alarmBase = DateTime.Now;
        alarmActive = false;
        recent.Clear();
        UpdateStats();
        StartListening();
    }

    // ================= listening =================

    private void StartListening()
    {
        listenError = null;
        cts = new CancellationTokenSource();
        _ = ListenLoopAsync(cts.Token);
    }

    private void StopListening()
    {
        try { cts?.Cancel(); } catch { }
        try { listener?.Stop(); } catch { }
        listener = null;
        foreach (var c in clients.ToList())
        {
            try { c.Tcp.Close(); } catch { }
        }
        UpdateStatus();
    }

    private async Task ListenLoopAsync(CancellationToken token)
    {
        while (!token.IsCancellationRequested)
        {
            try
            {
                var ip = IPAddress.Parse(settings.IpAddress);
                var l = new TcpListener(ip, settings.Port);
                l.Start();
                listener = l;
                listenError = null;
                Log($"Listening on {ip}:{settings.Port}");
                UpdateStatus();

                while (!token.IsCancellationRequested)
                {
                    TcpClient tc = await l.AcceptTcpClientAsync();
                    if (token.IsCancellationRequested) { tc.Close(); break; }
                    _ = HandleClientAsync(tc, token);
                }
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                if (token.IsCancellationRequested) break;
                listener = null;
                listenError = ex.Message;
                Log($"Listener error: {ex.Message} - trying again in 5 s");
                UpdateStatus();
                try { await Task.Delay(5000, token); }
                catch (OperationCanceledException) { break; }
            }
        }
    }

    private async Task HandleClientAsync(TcpClient tc, CancellationToken token)
    {
        if (!IsSenderAllowed(tc))
        {
            Log($"Rejected {tc.Client.RemoteEndPoint}: IP address is not in the allowed list");
            tc.Close();
            return;
        }

        if (settings.MaxClients > 0 && clients.Count >= settings.MaxClients)
        {
            Log($"Rejected {tc.Client.RemoteEndPoint}: max clients ({settings.MaxClients}) reached");
            tc.Close();
            return;
        }

        var c = new ClientState
        {
            Id = ++nextClientId,
            Tcp = tc,
            Stream = tc.GetStream(),
            Remote = tc.Client.RemoteEndPoint?.ToString() ?? "?",
            Since = DateTime.Now
        };
        c.Assembler.Mode = settings.Framing;
        c.Assembler.FixedLength = settings.FixedLength;

        c.Row = new ListViewItem(new[] { c.Id.ToString(), c.Remote, c.Since.ToString("HH:mm:ss"), "0" });
        lvClients.Items.Add(c.Row);
        clients.Add(c);
        Log($"Sender #{c.Id} connected: {c.Remote}");
        UpdateStatus();

        var buf = new byte[4096];
        try
        {
            while (!token.IsCancellationRequested)
            {
                int n = await c.Stream.ReadAsync(buf, token);
                if (n == 0) break;
                foreach (byte[] frame in c.Assembler.Feed(buf, n, w => Log($"#{c.Id}: {w}")))
                    await ProcessMessageAsync(c, frame);
            }
        }
        catch (OperationCanceledException) { }
        catch (IOException) { }
        catch (ObjectDisposedException) { }
        catch (Exception ex)
        {
            Log($"#{c.Id}: connection error: {ex.Message}");
        }
        finally
        {
            byte[]? rest = c.Assembler.Finish(w => Log($"#{c.Id}: {w}"));
            if (rest != null && !token.IsCancellationRequested) await ProcessMessageAsync(c, rest);

            clients.Remove(c);
            lvClients.Items.Remove(c.Row);
            try { tc.Close(); } catch { }
            Log($"Sender #{c.Id} disconnected");
            UpdateStatus();
        }
    }

    // None framing: a burst of data with no pause is one message
    private void PollGaps()
    {
        foreach (var c in clients.ToList())
        {
            byte[]? data = c.Assembler.PollGap(settings.MessageGapMs);
            if (data != null) _ = ProcessMessageAsync(c, data);
        }
    }

    // ================= one received message =================

    private async Task ProcessMessageAsync(ClientState c, byte[] content)
    {
        try
        {
            byte[] payload = FrameBuilder.Unwrap(content, settings.Framing, settings.Checksum, out bool? checksumOk);
            string text = Encoding.UTF8.GetString(payload);
            string trimmed = text.Trim();

            c.Messages++;
            c.Row.SubItems[3].Text = c.Messages.ToString();

            if (checksumOk == false)
            {
                Log($"#{c.Id}: BAD CHECKSUM - message rejected ({payload.Length} bytes)");
                if (settings.AutoAck) await ReplyAsync(c, settings.NakText);
                return;
            }

            if (trimmed.Length == 0)
            {
                // like the old Receiver: an empty message is written to the DB (timestamp only), but no file is created
                if (settings.LogEmptyToDb) AppendDb("");
                Log($"#{c.Id}: empty message ignored" + (settings.LogEmptyToDb ? " (logged to DB)" : ""));
                return;
            }

            if (settings.CommunicationTestString.Length > 0 && trimmed == settings.CommunicationTestString)
            {
                Log($"#{c.Id}: communication test received");
                if (settings.AutoAck) await ReplyAsync(c, settings.AckText);
                return;
            }

            if (settings.DuplicateWindowSec > 0 && IsDuplicate(trimmed))
            {
                duplicatesSkipped++;
                UpdateStats();
                Log($"#{c.Id}: duplicate message skipped (same text within {settings.DuplicateWindowSec} s)  [{Util.OneLine(text, 80)}]");
                if (settings.AutoAck) await ReplyAsync(c, settings.AckText);
                return;
            }

            AppendDb(text);                          // 1st: local DB, flushed to disk - the data is safe from here
            string fileName = SaveReceivedData(text); // 2nd: files; a folder that is down is kept in Pending and retried
            RegisterReceived();
            Log($"#{c.Id}: {payload.Length} bytes saved as {fileName}  [{Util.OneLine(text, 120)}]");

            if (settings.AutoAck) await ReplyAsync(c, settings.AckText);

            if (settings.AutoReplyEnabled && settings.AutoReplyText.Length > 0
                && (settings.AutoReplyMatch.Length == 0 || text.IndexOf(settings.AutoReplyMatch, StringComparison.OrdinalIgnoreCase) >= 0)
                && AllowAutoReply())
            {
                await ReplyAsync(c, settings.AutoReplyText);
            }
        }
        catch (Exception ex)
        {
            Log($"#{c.Id}: error while processing the message: {ex.Message}");
            if (settings.AutoAck) await ReplyAsync(c, settings.NakText);   // sender will try again
        }
    }

    private static readonly string PendingDir = Path.Combine(Application.StartupPath, "Pending");
    private int pendingCount;
    private long lastPendingTry;

    private string SaveReceivedData(string text)
    {
        string ext = Util.NormalizeExt(settings.FileFormat);
        string baseName = FileBaseName(text);
        string name = baseName + ext;   // same name as an older file = the old file is replaced by the new data
                                        // (the old data stays in the DB, see DB Search)

        bool ok = TrySave(0, settings.WorkingDirectory, name, text);
        if (!string.IsNullOrWhiteSpace(settings.WorkingDirectoryMonitor))
        {
            string monitorName = baseName + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ext;
            ok &= TrySave(1, settings.WorkingDirectoryMonitor, monitorName, text);
        }

        return ok ? name : name + "  (target folder not reachable - kept in Pending, will retry)";
    }

    // File name = the data in front of the first comma or space of the received message
    // (ALPCUCH0000101,0,0,GVD... -> ALPCUCH0000101.txt). If there is nothing usable, the old time-stamp name is used.
    private static string FileBaseName(string text)
    {
        string t = (text ?? "").TrimStart();
        int end = t.IndexOfAny(new[] { ',', ' ', '\t', '\r', '\n' });
        string first = (end < 0 ? t : t.Substring(0, end)).Trim();

        // characters Windows does not allow in a file name
        foreach (char bad in Path.GetInvalidFileNameChars())
            first = first.Replace(bad, '_');
        first = first.Trim('.', ' ');
        if (first.Length > 100) first = first.Substring(0, 100);

        return first.Length > 0 ? first : "M2M_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff");
    }

    // Saves one file; if the folder is not reachable (network drive down, disk full ...) the file is kept in
    // the local "Pending" folder next to the exe and delivered later by RetryPending.
    private bool TrySave(int target, string dir, string name, string text)
    {
        try
        {
            Directory.CreateDirectory(dir);
            WriteFileSafely(Path.Combine(dir, name), text);
            return true;
        }
        catch (Exception ex)
        {
            try
            {
                Directory.CreateDirectory(PendingDir);
                File.WriteAllText(Path.Combine(PendingDir, target + "__" + name), text, new UTF8Encoding(false));
                Log($"WARNING: cannot save to {dir}: {ex.Message} - kept in Pending");
                pendingCount++;
            }
            catch (Exception ex2)
            {
                Log($"WARNING: cannot save to {dir}: {ex.Message}; Pending also failed: {ex2.Message} (the message is still in the DB file)");
            }
            return false;
        }
    }

    // every 10 s: try to deliver the files waiting in Pending
    private void RetryPending()
    {
        long now = Environment.TickCount64;
        if (now - lastPendingTry < 10000) return;
        lastPendingTry = now;

        try
        {
            if (!Directory.Exists(PendingDir)) { pendingCount = 0; return; }

            string[] files = Directory.GetFiles(PendingDir);
            foreach (string f in files)
            {
                string name = Path.GetFileName(f);
                if (name.Length < 4 || name.IndexOf("__", StringComparison.Ordinal) != 1) continue;

                string target = name[0] == '0' ? settings.WorkingDirectory : settings.WorkingDirectoryMonitor;
                string real = name.Substring(3);
                if (string.IsNullOrWhiteSpace(target)) { File.Delete(f); continue; }

                try
                {
                    Directory.CreateDirectory(target);
                    WriteFileSafely(Path.Combine(target, real), File.ReadAllText(f));
                    File.Delete(f);
                    Log($"Pending file {real} delivered to {target}");
                }
                catch
                {
                    break;   // still not reachable - try again in 10 s
                }
            }
            int before = pendingCount;
            pendingCount = Directory.GetFiles(PendingDir).Length;
            if (before != pendingCount) UpdateStats();
        }
        catch { }
    }

    // write to .tmp first, then rename, so another program never reads a half-written file
    private static void WriteFileSafely(string path, string text)
    {
        string tmp = path + ".tmp";
        File.WriteAllText(tmp, text, new UTF8Encoding(false));
        if (File.Exists(path)) File.Delete(path);
        File.Move(tmp, path);
    }

    // DB\yyyy-MM-dd.udb, one record per message:  timestamp|content
    private static void AppendDb(string text)
    {
        Directory.CreateDirectory(DbDir);
        string file = Path.Combine(DbDir, DateTime.Now.ToString("yyyy-MM-dd") + ".udb");
        string line = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff}|{text.TrimEnd('\r', '\n')}\r\n";
        byte[] bytes = new UTF8Encoding(false).GetBytes(line);

        // flushed to the disk before we say "saved"; two quick retries if another program (backup / antivirus) holds the file
        for (int attempt = 1; ; attempt++)
        {
            try
            {
                using var fs = new FileStream(file, FileMode.Append, FileAccess.Write, FileShare.ReadWrite, 4096, FileOptions.WriteThrough);
                fs.Write(bytes, 0, bytes.Length);
                fs.Flush(true);
                return;
            }
            catch (IOException) when (attempt < 3)
            {
                Thread.Sleep(50);
            }
        }
    }

    // ================= allow-list / duplicates / statistics / alarm =================

    private bool IsSenderAllowed(TcpClient tc)
    {
        string list = settings.AllowedSenderIps;
        if (string.IsNullOrWhiteSpace(list)) return true;

        IPAddress? ip = (tc.Client.RemoteEndPoint as IPEndPoint)?.Address;
        if (ip == null) return false;
        if (ip.IsIPv4MappedToIPv6) ip = ip.MapToIPv4();
        string remote = ip.ToString();

        foreach (string part in list.Split(new[] { ',', ';', ' ' }, StringSplitOptions.RemoveEmptyEntries))
            if (part.Trim().Equals(remote, StringComparison.OrdinalIgnoreCase)) return true;
        return false;
    }

    private bool IsDuplicate(string key)
    {
        DateTime now = DateTime.Now;
        TimeSpan window = TimeSpan.FromSeconds(settings.DuplicateWindowSec);

        if (recent.Count > 0)
        {
            foreach (string old in recent.Where(kv => now - kv.Value >= window).Select(kv => kv.Key).ToList())
                recent.Remove(old);
        }

        if (recent.TryGetValue(key, out DateTime seen) && now - seen < window) return true;
        recent[key] = now;
        return false;
    }

    private void RollDayIfNeeded()
    {
        if (statsDay == DateTime.Today) return;
        statsDay = DateTime.Today;
        todayCount = 0;
        duplicatesSkipped = 0;
    }

    private void RegisterReceived()
    {
        RollDayIfNeeded();
        todayCount++;
        lastReceived = DateTime.Now;
        alarmBase = lastReceived;
        if (alarmActive)
        {
            alarmActive = false;
            Log("Data received again - no-data alarm cleared");
        }
        UpdateStats();
    }

    // called by the timer; does its work once per second
    private void SecondTick()
    {
        long now = Environment.TickCount64;
        if (now - lastSecondTick < 1000) return;
        lastSecondTick = now;

        RollDayIfNeeded();
        RetryPending();

        int limit = settings.NoDataAlarmMinutes;
        if (limit > 0 && listener != null)
        {
            double minutes = (DateTime.Now - alarmBase).TotalMinutes;
            if (minutes >= limit)
            {
                if (!alarmActive)
                {
                    alarmActive = true;
                    Log($"ALARM: no data received for {limit} minute(s)");
                    try { System.Media.SystemSounds.Exclamation.Play(); } catch { }
                }
                UpdateStats();
                return;
            }
        }
        if (alarmActive)
        {
            alarmActive = false;
            UpdateStats();
        }
    }

    private void UpdateStats()
    {
        if (IsDisposed) return;

        string last = lastReceived == DateTime.MinValue ? "-" : lastReceived.ToString("HH:mm:ss");
        string text = $"Today: {todayCount} message(s)   |   Last received: {last}   |   Duplicates skipped: {duplicatesSkipped}";
        if (pendingCount > 0) text += $"   |   WAITING IN PENDING: {pendingCount}";

        if (alarmActive)
        {
            int mins = (int)(DateTime.Now - alarmBase).TotalMinutes;
            lblStats.ForeColor = Color.White;
            lblStats.BackColor = Color.Firebrick;
            lblStats.Text = $"NO DATA FOR {mins} MIN!   " + text;
        }
        else
        {
            lblStats.ForeColor = Color.DimGray;
            lblStats.BackColor = SystemColors.Control;
            lblStats.Text = text;
        }
    }

    // ================= replies =================

    private async Task ReplyAsync(ClientState c, string text)
    {
        if (text.Length == 0) return;
        try
        {
            byte[] frame = FrameBuilder.Wrap(Encoding.UTF8.GetBytes(text), settings.Framing, settings.Checksum, settings.FixedLength);
            await c.WriteLock.WaitAsync();
            try { await c.Stream.WriteAsync(frame); }
            finally { c.WriteLock.Release(); }
            Log($"#{c.Id}: replied \"{text}\"");
        }
        catch (Exception ex)
        {
            Log($"#{c.Id}: reply failed: {ex.Message}");
        }
    }

    private bool AllowAutoReply()
    {
        long now = Environment.TickCount64;
        if (now - autoWindowStart > 1000)
        {
            autoWindowStart = now;
            autoWindowCount = 0;
        }
        if (++autoWindowCount <= 200) return true;

        if (settings.AutoReplyEnabled)
        {
            settings.AutoReplyEnabled = false;
            Log("Auto-reply switched OFF: more than 200 automatic replies in one second (two devices answering each other?). Turn it on again in Settings.");
        }
        return false;
    }

    // ================= status / log =================

    private void UpdateStatus()
    {
        if (IsDisposed) return;

        if (listener == null)
        {
            lblStatus.ForeColor = Color.Red;
            lblStatus.Text = listenError == null ? "Not listening" : "Cannot listen: " + listenError;
        }
        else if (clients.Count == 0)
        {
            lblStatus.ForeColor = Color.Red;
            lblStatus.Text = $"Waiting for data on {settings.IpAddress}:{settings.Port} ...";
        }
        else
        {
            lblStatus.ForeColor = Color.DarkGreen;
            lblStatus.Text = $"{settings.ReceiverDisplayName} Is Receiving Data From {settings.MachineA} Now...  ({clients.Count} sender(s))";
        }
    }

    private void Log(string text)
    {
        if (IsDisposed) return;
        if (InvokeRequired) { BeginInvoke(() => Log(text)); return; }
        txtLog.AddLine(text);
    }

    // ================= closing (password, like the old app) =================

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        if (e.CloseReason == CloseReason.UserClosing)
        {
            if (!PasswordGate.Ask(this, cfg, "Close"))
            {
                e.Cancel = true;
                return;
            }
        }
        gapTimer.Stop();
        StopListening();
        base.OnFormClosing(e);
    }
}
